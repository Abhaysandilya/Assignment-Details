
# AI Component Playground

## 🧠 Project Overview

The AI Component Playground is an interactive full-stack web application that enables users to generate, preview, and iteratively refine React components using natural language prompts. It serves as a powerful sandbox for developers and designers looking to rapidly prototype UI elements using AI assistance.

## 🔧 Tech Stack

- **Frontend**: Next.js 15 (App Router)
- **Backend**: Node.js + Express.js
- **Database**: PostgreSQL (can switch to SQLite or MySQL)
- **Authentication**: Basic JWT-based setup
- **Styling**: Tailwind CSS, ShadCN components
- **Deployment**: Vercel (Frontend), Render/Fly.io (Backend)

## 📂 Folder Structure

```bash
ai-component-playground/
│
├── backend/
│   ├── server.js
│   ├── .env
│   ├── routers/
│   │   └── auth.js
│   └── models/
│       └── User.js
│
├── frontend/
│   ├── app/
│   │   ├── page.tsx
│   │   ├── layout.tsx
│   │   └── components/
│   │       └── ChatBox.tsx
│   └── utils/
│       └── fetcher.ts
```

## ✨ Features

- ✍️ Chat interface to generate UI components
- ♻️ Iterative component refinement
- 💾 State saving across sessions
- 🧱 Uses AI prompts to scaffold React + Tailwind code
- 💡 Supports editing via form-based tools (optional)

## 📜 API Routes (Example)

- `POST /api/generate` – Generate a component based on a prompt
- `POST /api/refine` – Refine previously generated code
- `POST /api/save` – Save current session

## 🧪 Future Enhancements

- GitHub login + repo deployment
- OpenAI GPT-4o streaming integration
- Monaco Editor integration
- Prompt history & comparison view

## 🔐 AI Disclosure

AI assistance (ChatGPT & Cursor AI) was used to write, debug, and document parts of this project.
